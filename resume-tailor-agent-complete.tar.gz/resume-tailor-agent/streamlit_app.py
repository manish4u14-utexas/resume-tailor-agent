#!/usr/bin/env python3
"""
Resume Tailor Agent - Streamlit Web Interface

This provides a user-friendly web interface for the Resume Tailor Agent.
"""

import streamlit as st
import os
import sys
import tempfile
from io import BytesIO
import traceback

# Add the src directory to the path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.resume_parser import ResumeParser
from src.llm_interface import LLMInterface
from src.utils import log_message


def setup_page():
    """Setup the Streamlit page configuration."""
    st.set_page_config(
        page_title="Resume Tailor Agent",
        page_icon="📄",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    st.title("📄 Resume Tailor Agent")
    st.markdown("**Tailor your resume to specific job descriptions using AI**")
    
    # Add some styling
    st.markdown("""
    <style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        margin-bottom: 1rem;
    }
    .step-header {
        font-size: 1.2rem;
        font-weight: bold;
        color: #1f77b4;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }
    .success-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        color: #155724;
        margin: 1rem 0;
    }
    .error-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #f8d7da;
        border: 1px solid #f5c6cb;
        color: #721c24;
        margin: 1rem 0;
    }
    .info-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #d1ecf1;
        border: 1px solid #bee5eb;
        color: #0c5460;
        margin: 1rem 0;
    }
    </style>
    """, unsafe_allow_html=True)


def show_sidebar():
    """Show the sidebar with model selection and information."""
    st.sidebar.header("⚙️ Configuration")
    
    # Model selection
    model_options = {
        "local": "Local Ollama (Free)",
        "openai": "OpenAI GPT (Paid)",
        "anthropic": "Anthropic Claude (Paid)"
    }
    
    selected_model = st.sidebar.selectbox(
        "Select LLM Model:",
        options=list(model_options.keys()),
        format_func=lambda x: model_options[x],
        index=0
    )
    
    # Show model information
    st.sidebar.markdown("### 📋 Model Information")
    
    if selected_model == "local":
        st.sidebar.info("""
        **Local Ollama**
        - Completely free
        - Runs on your machine
        - Requires Ollama installation
        - Good for privacy
        """)
    elif selected_model == "openai":
        st.sidebar.info("""
        **OpenAI GPT**
        - Paid API service
        - High quality results
        - Requires API key
        - Fast processing
        """)
    elif selected_model == "anthropic":
        st.sidebar.info("""
        **Anthropic Claude**
        - Paid API service
        - Excellent reasoning
        - Requires API key
        - Great for complex tasks
        """)
    
    # API key input for paid services
    api_key = None
    if selected_model == "openai":
        api_key = st.sidebar.text_input(
            "OpenAI API Key:",
            type="password",
            help="Enter your OpenAI API key"
        )
        if api_key:
            os.environ['OPENAI_API_KEY'] = api_key
    elif selected_model == "anthropic":
        api_key = st.sidebar.text_input(
            "Anthropic API Key:",
            type="password",
            help="Enter your Anthropic API key"
        )
        if api_key:
            os.environ['ANTHROPIC_API_KEY'] = api_key
    
    # Test connection button
    if st.sidebar.button("🔍 Test Connection"):
        test_llm_connection(selected_model)
    
    return selected_model


def test_llm_connection(model):
    """Test LLM connection and show results."""
    with st.sidebar:
        with st.spinner(f"Testing {model} connection..."):
            try:
                interface = LLMInterface()
                available_models = interface.get_available_models()
                
                if model in available_models and available_models[model]:
                    success = interface.test_connection(model)
                    if success:
                        st.success(f"✅ {model} connection successful!")
                    else:
                        st.error(f"❌ {model} connection failed")
                else:
                    st.error(f"❌ {model} not available or not configured")
                    
                    # Show setup instructions
                    if model == "local":
                        st.info("""
                        To use local Ollama:
                        1. Install Ollama
                        2. Run: `ollama pull mistral`
                        3. Start Ollama service
                        """)
                    elif model in ["openai", "anthropic"]:
                        st.info(f"Please provide your {model.upper()} API key in the sidebar")
                        
            except Exception as e:
                st.error(f"❌ Connection test failed: {str(e)}")


def upload_resume():
    """Handle resume file upload."""
    st.markdown('<div class="step-header">📤 Step 1: Upload Your Resume</div>', unsafe_allow_html=True)
    
    uploaded_file = st.file_uploader(
        "Choose your resume file (.docx format)",
        type=['docx'],
        help="Upload your resume in Microsoft Word (.docx) format"
    )
    
    if uploaded_file is not None:
        # Save uploaded file to temporary location
        temp_dir = tempfile.mkdtemp()
        temp_path = os.path.join(temp_dir, uploaded_file.name)
        
        with open(temp_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        
        st.success(f"✅ Resume uploaded: {uploaded_file.name}")
        
        # Show resume preview
        with st.expander("📋 Preview Resume Sections"):
            try:
                parser = ResumeParser(temp_path)
                if parser.load_document():
                    sections = parser.extract_sections()
                    
                    for section_name, content in sections.items():
                        if content.strip():
                            st.subheader(section_name.title())
                            st.text(content[:300] + "..." if len(content) > 300 else content)
                else:
                    st.error("Failed to load resume document")
            except Exception as e:
                st.error(f"Error previewing resume: {str(e)}")
        
        return temp_path
    
    return None


def input_job_description():
    """Handle job description input."""
    st.markdown('<div class="step-header">📝 Step 2: Provide Job Description</div>', unsafe_allow_html=True)
    
    input_method = st.radio(
        "How would you like to provide the job description?",
        ["Paste text directly", "Upload text file"],
        horizontal=True
    )
    
    jd_content = None
    
    if input_method == "Paste text directly":
        jd_content = st.text_area(
            "Job Description:",
            height=200,
            placeholder="Paste the job description here...",
            help="Copy and paste the job description from the job posting"
        )
    else:
        uploaded_jd = st.file_uploader(
            "Choose job description file (.txt format)",
            type=['txt'],
            help="Upload a text file containing the job description"
        )
        
        if uploaded_jd is not None:
            jd_content = str(uploaded_jd.read(), "utf-8")
            st.success(f"✅ Job description loaded: {uploaded_jd.name}")
    
    if jd_content and jd_content.strip():
        st.success(f"✅ Job description loaded ({len(jd_content)} characters)")
        
        with st.expander("📋 Preview Job Description"):
            st.text(jd_content[:500] + "..." if len(jd_content) > 500 else jd_content)
        
        return jd_content.strip()
    
    return None


def tailor_resume(resume_path, jd_content, model):
    """Tailor the resume using the selected model."""
    st.markdown('<div class="step-header">🤖 Step 3: AI Resume Tailoring</div>', unsafe_allow_html=True)
    
    if st.button("🚀 Tailor My Resume", type="primary"):
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        try:
            # Step 1: Initialize components
            status_text.text("Initializing AI components...")
            progress_bar.progress(10)
            
            interface = LLMInterface()
            parser = ResumeParser(resume_path)
            
            # Step 2: Load and parse resume
            status_text.text("Loading and parsing resume...")
            progress_bar.progress(25)
            
            if not parser.load_document():
                st.error("❌ Failed to load resume document")
                return None
            
            sections = parser.extract_sections()
            non_empty_sections = {k: v for k, v in sections.items() if v.strip()}
            
            if not non_empty_sections:
                st.error("❌ No content sections found in resume")
                return None
            
            # Step 3: Build prompt
            status_text.text("Building AI prompt...")
            progress_bar.progress(40)
            
            sections_text = ""
            for section_name, content in non_empty_sections.items():
                sections_text += f"\n{section_name.upper()}:\n{content}\n"
            
            prompt = f"""
You are an expert resume writer. Your task is to tailor the following resume sections to match the provided job description.

JOB DESCRIPTION:
{jd_content}

ORIGINAL RESUME SECTIONS:
{sections_text}

INSTRUCTIONS:
1. Rewrite the SUMMARY section to highlight relevant experience and skills for this specific job
2. Update the SKILLS section to emphasize the most relevant technical and soft skills
3. Enhance the EXPERIENCE section by rewriting bullet points to better align with the job requirements
4. Maintain the original tone and style of the resume
5. Keep the same formatting structure
6. Do not add false information - only reframe existing content

Please provide the updated sections in the following format:

SUMMARY:
[Updated summary here]

SKILLS:
[Updated skills here]

EXPERIENCE:
[Updated experience here]
"""
            
            # Step 4: Get AI response
            status_text.text(f"Getting AI response from {model}...")
            progress_bar.progress(60)
            
            response = interface.run_llm(prompt, model)
            
            if not response:
                st.error("❌ No response received from AI model")
                return None
            
            # Step 5: Parse response
            status_text.text("Processing AI response...")
            progress_bar.progress(80)
            
            # Simple parsing of the response
            tailored_sections = {}
            current_section = None
            current_content = []
            
            for line in response.split('\n'):
                line = line.strip()
                if line.upper().startswith('SUMMARY:'):
                    if current_section:
                        tailored_sections[current_section] = '\n'.join(current_content).strip()
                    current_section = 'summary'
                    current_content = [line.replace('SUMMARY:', '').strip()]
                elif line.upper().startswith('SKILLS:'):
                    if current_section:
                        tailored_sections[current_section] = '\n'.join(current_content).strip()
                    current_section = 'skills'
                    current_content = [line.replace('SKILLS:', '').strip()]
                elif line.upper().startswith('EXPERIENCE:'):
                    if current_section:
                        tailored_sections[current_section] = '\n'.join(current_content).strip()
                    current_section = 'experience'
                    current_content = [line.replace('EXPERIENCE:', '').strip()]
                elif current_section and line:
                    current_content.append(line)
            
            # Save the last section
            if current_section:
                tailored_sections[current_section] = '\n'.join(current_content).strip()
            
            # Step 6: Update resume
            status_text.text("Updating resume document...")
            progress_bar.progress(90)
            
            if not parser.update_sections(tailored_sections):
                st.error("❌ Failed to update resume sections")
                return None
            
            # Step 7: Save updated resume
            status_text.text("Saving tailored resume...")
            progress_bar.progress(95)
            
            output_path = os.path.join(tempfile.mkdtemp(), "tailored_resume.docx")
            if not parser.save_document(output_path):
                st.error("❌ Failed to save updated resume")
                return None
            
            progress_bar.progress(100)
            status_text.text("✅ Resume tailoring completed!")
            
            st.success("🎉 Resume successfully tailored!")
            
            # Show tailored sections
            st.markdown("### 📋 Tailored Sections")
            for section_name, content in tailored_sections.items():
                if content.strip():
                    with st.expander(f"📝 {section_name.title()}"):
                        st.text(content)
            
            return output_path
            
        except Exception as e:
            st.error(f"❌ Error during resume tailoring: {str(e)}")
            st.error("Full error details:")
            st.code(traceback.format_exc())
            return None
    
    return None


def download_resume(output_path):
    """Provide download link for the tailored resume."""
    if output_path and os.path.exists(output_path):
        st.markdown('<div class="step-header">⬇️ Step 4: Download Your Tailored Resume</div>', unsafe_allow_html=True)
        
        with open(output_path, "rb") as file:
            btn = st.download_button(
                label="📥 Download Tailored Resume",
                data=file.read(),
                file_name="tailored_resume.docx",
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            )
        
        st.success("✅ Your tailored resume is ready for download!")


def main():
    """Main Streamlit application."""
    setup_page()
    
    # Show sidebar
    selected_model = show_sidebar()
    
    # Main content
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Step 1: Upload resume
        resume_path = upload_resume()
        
        # Step 2: Input job description
        jd_content = input_job_description()
        
        # Step 3: Tailor resume (only if both inputs are provided)
        output_path = None
        if resume_path and jd_content:
            output_path = tailor_resume(resume_path, jd_content, selected_model)
        
        # Step 4: Download tailored resume
        if output_path:
            download_resume(output_path)
    
    with col2:
        st.markdown("### 📚 How It Works")
        st.markdown("""
        1. **Upload** your resume in .docx format
        2. **Provide** the job description
        3. **Select** your preferred AI model
        4. **Click** "Tailor My Resume"
        5. **Download** your customized resume
        """)
        
        st.markdown("### 🎯 Benefits")
        st.markdown("""
        - **Targeted**: Matches job requirements
        - **Professional**: Maintains formatting
        - **Fast**: Results in minutes
        - **Flexible**: Multiple AI models
        - **Private**: Local processing option
        """)
        
        st.markdown("### 💡 Tips")
        st.markdown("""
        - Use complete job descriptions
        - Ensure resume has clear sections
        - Review AI suggestions carefully
        - Test different AI models
        - Keep original resume backup
        """)


if __name__ == "__main__":
    main()

