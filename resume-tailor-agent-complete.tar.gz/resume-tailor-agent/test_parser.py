#!/usr/bin/env python3
"""
Test script for the resume parser functionality.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.resume_parser import ResumeParser, create_sample_resume
from src.utils import validate_file_path, read_text_file


def test_sample_resume_creation():
    """Test creating a sample resume."""
    print("Testing sample resume creation...")
    
    sample_path = "data/resume_template.docx"
    success = create_sample_resume(sample_path)
    
    if success and validate_file_path(sample_path, '.docx'):
        print("✓ Sample resume created successfully")
        return True
    else:
        print("✗ Failed to create sample resume")
        return False


def test_resume_parsing():
    """Test parsing the sample resume."""
    print("\nTesting resume parsing...")
    
    resume_path = "data/resume_template.docx"
    
    if not validate_file_path(resume_path, '.docx'):
        print("✗ Resume file not found")
        return False
    
    parser = ResumeParser(resume_path)
    
    if not parser.load_document():
        print("✗ Failed to load document")
        return False
    
    sections = parser.extract_sections()
    
    print(f"✓ Document loaded successfully")
    print(f"✓ Extracted {len([s for s in sections.values() if s])} sections with content")
    
    # Print extracted sections
    for section_name, content in sections.items():
        if content:
            print(f"\n--- {section_name.upper()} ---")
            print(content[:200] + "..." if len(content) > 200 else content)
    
    return True


def test_document_info():
    """Test getting document information."""
    print("\nTesting document info extraction...")
    
    resume_path = "data/resume_template.docx"
    parser = ResumeParser(resume_path)
    
    if parser.load_document():
        info = parser.get_document_info()
        print(f"✓ Document info: {info}")
        return True
    else:
        print("✗ Failed to get document info")
        return False


def main():
    """Run all tests."""
    print("=== Resume Parser Test Suite ===\n")
    
    tests = [
        test_sample_resume_creation,
        test_resume_parsing,
        test_document_info
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"✗ Test failed with exception: {e}")
    
    print(f"\n=== Test Results ===")
    print(f"Passed: {passed}/{total}")
    
    if passed == total:
        print("🎉 All tests passed!")
        return 0
    else:
        print("❌ Some tests failed")
        return 1


if __name__ == "__main__":
    sys.exit(main())

