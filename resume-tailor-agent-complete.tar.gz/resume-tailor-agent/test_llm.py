#!/usr/bin/env python3
"""
Test script for the LLM interface functionality.
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.llm_interface import LLMInterface, run_llm
from src.utils import read_text_file


def test_llm_interface_initialization():
    """Test LLM interface initialization."""
    print("Testing LLM interface initialization...")
    
    try:
        interface = LLMInterface()
        available_models = interface.get_available_models()
        
        print("✓ LLM interface initialized successfully")
        print(f"✓ Available models: {available_models}")
        
        return True, interface
    except Exception as e:
        print(f"✗ Failed to initialize LLM interface: {e}")
        return False, None


def test_connection_tests(interface):
    """Test connections to different LLM providers."""
    print("\nTesting LLM provider connections...")
    
    providers_to_test = ['local']  # Start with local only
    
    # Check if API keys are available
    if os.getenv('OPENAI_API_KEY'):
        providers_to_test.append('openai')
    
    if os.getenv('ANTHROPIC_API_KEY'):
        providers_to_test.append('anthropic')
    
    results = {}
    
    for provider in providers_to_test:
        print(f"Testing {provider}...")
        try:
            success = interface.test_connection(provider)
            results[provider] = success
            if success:
                print(f"✓ {provider} connection successful")
            else:
                print(f"✗ {provider} connection failed")
        except Exception as e:
            print(f"✗ {provider} connection test failed with exception: {e}")
            results[provider] = False
    
    return results


def test_simple_prompt(interface):
    """Test a simple prompt with available providers."""
    print("\nTesting simple prompts...")
    
    test_prompt = "Please write a brief professional summary for a software developer with 3 years of experience in Python and web development."
    
    # Test with local model first
    print("Testing with local model...")
    try:
        response = interface.run_llm(test_prompt, "local")
        if response:
            print("✓ Local model response received")
            print(f"Response preview: {response[:100]}...")
            return True
        else:
            print("✗ No response from local model")
            return False
    except Exception as e:
        print(f"✗ Local model test failed: {e}")
        return False


def test_resume_tailoring_prompt(interface):
    """Test a resume tailoring prompt."""
    print("\nTesting resume tailoring prompt...")
    
    # Read the sample job description
    jd_content = read_text_file("data/jd.txt")
    if not jd_content:
        print("✗ Could not read job description file")
        return False
    
    # Create a sample resume section
    sample_summary = """Experienced software developer with 5+ years of experience in full-stack development. 
    Proficient in Python, JavaScript, and cloud technologies. Strong problem-solving skills 
    and experience in agile development environments."""
    
    sample_skills = """• Programming Languages: Python, JavaScript, Java, C++
• Web Technologies: React, Node.js, HTML5, CSS3
• Databases: PostgreSQL, MongoDB, Redis
• Cloud Platforms: AWS, Azure, Google Cloud
• Tools: Git, Docker, Kubernetes, Jenkins"""
    
    tailoring_prompt = f"""
You are an expert resume writer. Please tailor the following resume sections to match this job description:

JOB DESCRIPTION:
{jd_content}

CURRENT RESUME SECTIONS:

SUMMARY:
{sample_summary}

SKILLS:
{sample_skills}

Please rewrite these sections to better align with the job requirements while maintaining accuracy and professionalism.

Provide your response in this format:

SUMMARY:
[Updated summary here]

SKILLS:
[Updated skills here]
"""
    
    try:
        response = interface.run_llm(tailoring_prompt, "local")
        if response:
            print("✓ Resume tailoring response received")
            print(f"Response length: {len(response)} characters")
            print("\n--- TAILORED RESPONSE ---")
            print(response[:500] + "..." if len(response) > 500 else response)
            return True
        else:
            print("✗ No response from resume tailoring prompt")
            return False
    except Exception as e:
        print(f"✗ Resume tailoring test failed: {e}")
        return False


def main():
    """Run all LLM tests."""
    print("=== LLM Interface Test Suite ===\n")
    
    # Test 1: Initialization
    success, interface = test_llm_interface_initialization()
    if not success:
        print("❌ Cannot proceed without LLM interface")
        return 1
    
    # Test 2: Connection tests
    connection_results = test_connection_tests(interface)
    
    # Test 3: Simple prompt (only if we have at least one working connection)
    if any(connection_results.values()):
        test_simple_prompt(interface)
        test_resume_tailoring_prompt(interface)
    else:
        print("\n⚠️  No working LLM connections found. Skipping prompt tests.")
        print("To test LLM functionality:")
        print("1. For local: Install and run Ollama with 'ollama pull mistral'")
        print("2. For OpenAI: Set OPENAI_API_KEY environment variable")
        print("3. For Anthropic: Set ANTHROPIC_API_KEY environment variable")
    
    print(f"\n=== Test Summary ===")
    print(f"Interface initialization: {'✓' if success else '✗'}")
    for provider, result in connection_results.items():
        print(f"{provider} connection: {'✓' if result else '✗'}")
    
    if success and any(connection_results.values()):
        print("🎉 LLM interface is ready to use!")
        return 0
    else:
        print("⚠️  LLM interface has limited functionality")
        return 1


if __name__ == "__main__":
    sys.exit(main())

